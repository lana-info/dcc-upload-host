<?php
/*
Plugin Name: DCC Runtime Patch
Description: Frontend and quota patch for the Digital Creator Club prompt generator.
Version: 1.2.6
*/

if (!defined('ABSPATH')) {
    exit;
}

function dccrp_tool_suffix($tool_id) {
    $map = array(
        'clipart-generator' => 'clipart_generator',
        'bundle-planner' => 'bundle_planner',
        'seo-helper' => 'seo_helper',
    );
    return $map[$tool_id] ?? 'clipart_generator';
}

function dccrp_cycle_day($user_id) {
    $day = (int) get_user_meta($user_id, 'dcc_cycle_day', true);
    if ($day < 1 || $day > 31) {
        $day = 1;
    }
    return $day;
}

function dccrp_cycle_start_for($timestamp, $cycle_day) {
    $cycle_day = max(1, min(31, (int) $cycle_day));
    $year = (int) wp_date('Y', $timestamp);
    $month = (int) wp_date('n', $timestamp);
    $day = (int) wp_date('j', $timestamp);
    $days_in_month = (int) wp_date('t', $timestamp);

    $current_start = min($cycle_day, $days_in_month);
    if ($day >= $current_start) {
        return sprintf('%04d-%02d-%02d', $year, $month, $current_start);
    }

    $prev = strtotime('-1 month', $timestamp);
    $prev_year = (int) wp_date('Y', $prev);
    $prev_month = (int) wp_date('n', $prev);
    $prev_day = min($cycle_day, (int) wp_date('t', $prev));
    return sprintf('%04d-%02d-%02d', $prev_year, $prev_month, $prev_day);
}

function dccrp_get_base_limit($settings, $tool_id) {
    return max(1, (int) ($settings['monthly_credits'] ?? 100));
}

function dccrp_get_user_limit($user_id, $tool_id, $settings) {
    $bonus = (int) get_user_meta($user_id, 'dcc_bonus_all_tools', true);
    return max(1, dccrp_get_base_limit($settings, $tool_id) + $bonus);
}

function dccrp_ensure_quota($user_id, $tool_id, $settings = null) {
    if (!is_array($settings)) {
        $settings = function_exists('dcc_get_settings') ? dcc_get_settings() : array();
    }
    $window_key = 'dcc_quota_window';
    $limit_key = 'dcc_credits_limit';
    $remaining_key = 'dcc_credits_remaining';

    $window = dccrp_cycle_start_for(current_time('timestamp'), dccrp_cycle_day($user_id));
    $limit = dccrp_get_user_limit($user_id, $tool_id, $settings);
    $stored_window = (string) get_user_meta($user_id, $window_key, true);
    $stored_remaining = get_user_meta($user_id, $remaining_key, true);

    if ($stored_window !== $window || $stored_remaining === '') {
        update_user_meta($user_id, $window_key, $window);
        update_user_meta($user_id, $limit_key, $limit);
        update_user_meta($user_id, $remaining_key, $limit);
    } else {
        $stored_limit = (int) get_user_meta($user_id, $limit_key, true);
        if ($stored_limit !== $limit) {
            $new_remaining = max(0, (int) $stored_remaining + ($limit - $stored_limit));
            update_user_meta($user_id, $limit_key, $limit);
            update_user_meta($user_id, $remaining_key, $new_remaining);
        }
    }

    return array(
        'limit' => (int) get_user_meta($user_id, $limit_key, true),
        'remaining' => (int) get_user_meta($user_id, $remaining_key, true),
        'window' => (string) get_user_meta($user_id, $window_key, true),
        'cycle_day' => dccrp_cycle_day($user_id),
    );
}

function dccrp_consume_quota($user_id, $tool_id, $amount) {
    $remaining_key = 'dcc_credits_remaining';
    $remaining = (int) get_user_meta($user_id, $remaining_key, true);
    $new_remaining = max(0, $remaining - max(0, (int) $amount));
    update_user_meta($user_id, $remaining_key, $new_remaining);
    return $new_remaining;
}

function dccrp_profile_fields($user) {
    if (!current_user_can('manage_options')) {
        return;
    }
    $cycle_day = dccrp_cycle_day($user->ID);
    $bonus_all = (int) get_user_meta($user->ID, 'dcc_bonus_all_tools', true);
    ?>
    <h2>Digital Creator Club quotas</h2>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="dcc_cycle_day">Credit cycle start day</label></th>
            <td>
                <input type="number" min="1" max="31" class="regular-text" name="dcc_cycle_day" id="dcc_cycle_day" value="<?php echo esc_attr((string) $cycle_day); ?>" />
                <p class="description">1-31. If this day does not exist in the current month, the last day of month is used.</p>
            </td>
        </tr>
        <tr>
            <th><label for="dcc_bonus_all_tools">Bonus credits (all tools)</label></th>
            <td><input type="number" step="1" class="regular-text" name="dcc_bonus_all_tools" id="dcc_bonus_all_tools" value="<?php echo esc_attr((string) $bonus_all); ?>" /></td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'dccrp_profile_fields');
add_action('edit_user_profile', 'dccrp_profile_fields');

function dccrp_save_profile_fields($user_id) {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (!isset($_POST['dcc_cycle_day'])) {
        return;
    }
    update_user_meta($user_id, 'dcc_cycle_day', max(1, min(31, (int) $_POST['dcc_cycle_day'])));
    update_user_meta($user_id, 'dcc_bonus_all_tools', isset($_POST['dcc_bonus_all_tools']) ? (int) $_POST['dcc_bonus_all_tools'] : 0);
}
add_action('personal_options_update', 'dccrp_save_profile_fields');
add_action('edit_user_profile_update', 'dccrp_save_profile_fields');

add_action('init', function () {
    remove_action('wp_ajax_dcc_generate_clipart', 'dcc_ajax_generate_clipart');
    add_action('wp_ajax_dcc_generate_clipart', 'dccrp_ajax_generate_clipart');
}, 20);

function dccrp_ajax_generate_clipart() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Войдите в аккаунт, чтобы выполнить генерацию.'), 401);
    }
    if (!function_exists('dcc_get_settings') || !function_exists('dcc_generate_groups_via_openrouter_batched')) {
        wp_send_json_error(array('message' => 'Базовый плагин не готов к генерации.'), 500);
    }

    $settings = dcc_get_settings();
    $user_id = get_current_user_id();
    $quota = dccrp_ensure_quota($user_id, 'clipart-generator', $settings);

    $palette_mode = sanitize_text_field($_POST['palette_mode'] ?? 'preset');
    $preset_palette = sanitize_text_field($_POST['preset_palette'] ?? 'beige_boho');
    $palette_value = 'auto';
    if ($palette_mode === 'preset') {
        $palette_value = $preset_palette;
    } elseif (in_array($palette_mode, array('custom', 'match_images', 'auto'), true)) {
        $palette_value = $palette_mode;
    }

    $payload = array(
        'mode' => sanitize_text_field($_POST['mode'] ?? 'prompts'),
        'theme' => sanitize_text_field($_POST['theme'] ?? ''),
        'template' => sanitize_textarea_field($_POST['template'] ?? ''),
        'rules' => sanitize_textarea_field($_POST['rules'] ?? ''),
        'palette' => $palette_value,
        'custom_colors' => sanitize_textarea_field($_POST['custom_colors'] ?? ''),
        'groups' => array(),
        'reference_images' => function_exists('dcc_collect_reference_images_from_request') ? dcc_collect_reference_images_from_request() : array(),
    );

    $group_names = isset($_POST['group_name']) ? (array) $_POST['group_name'] : array();
    $group_counts = isset($_POST['group_count']) ? (array) $_POST['group_count'] : array();
    foreach ($group_names as $index => $name) {
        $payload['groups'][] = array(
            'name' => sanitize_text_field($name),
            'count' => isset($group_counts[$index]) ? (int) $group_counts[$index] : 1,
        );
    }

    $payload['groups'] = function_exists('dcc_normalize_groups') ? dcc_normalize_groups($payload['groups']) : $payload['groups'];
    if (empty($payload['groups'])) {
        wp_send_json_error(array('message' => 'Добавьте хотя бы одну группу.'), 400);
    }

    if (count($payload['groups']) > (int) ($settings['max_groups'] ?? 15)) {
        wp_send_json_error(array('message' => 'Слишком много групп для одного набора.'), 400);
    }
    foreach ($payload['groups'] as $group) {
        if ((int) $group['count'] > (defined('DCC_MAX_ITEMS_PER_GROUP') ? DCC_MAX_ITEMS_PER_GROUP : 30)) {
            wp_send_json_error(array('message' => 'В одной из групп превышен лимит количества элементов.'), 400);
        }
    }

    $items_requested = function_exists('dcc_total_items') ? dcc_total_items($payload['groups']) : 0;
    $tool_cost = function_exists('dcc_get_tool_request_cost')
        ? dcc_get_tool_request_cost('clipart-generator', $settings)
        : max(1, (int) ($settings['request_cost_clipart_generator'] ?? 1));
    $cost = max(0, (int) $items_requested) * $tool_cost;
    if ($cost > (int) $quota['remaining']) {
        wp_send_json_error(array(
            'message' => 'Недостаточно кредитов для этой генерации.',
            'remaining' => (int) $quota['remaining'],
            'cost' => $cost,
        ), 402);
    }

    $results = dcc_generate_groups_via_openrouter_batched(
        $payload,
        $settings,
        3,
        function ($batch_cost) use ($user_id) {
            dccrp_consume_quota($user_id, 'clipart-generator', (int) $batch_cost);
        }
    );
    if (is_wp_error($results)) {
        wp_send_json_error(array('message' => $results->get_error_message()), 502);
    }

    $updated = dccrp_ensure_quota($user_id, 'clipart-generator', $settings);
    wp_send_json_success(array(
        'results' => $results,
        'cost' => $cost,
        'remaining' => (int) $updated['remaining'],
        'limit' => (int) $updated['limit'],
        'generated_at' => current_time('mysql'),
    ));
}

add_action('wp_ajax_dccrp_get_quota', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Unauthorized'), 401);
    }
    $settings = function_exists('dcc_get_settings') ? dcc_get_settings() : array();
    $quota = dccrp_ensure_quota(get_current_user_id(), 'clipart-generator', $settings);
    wp_send_json_success(array(
        'remaining' => (int) $quota['remaining'],
        'limit' => (int) $quota['limit'],
        'window' => (string) $quota['window'],
        'cycle_day' => (int) $quota['cycle_day'],
    ));
});

add_action('wp_enqueue_scripts', function () {
    if (!wp_script_is('dcc-frontend', 'registered') && !wp_script_is('dcc-frontend', 'enqueued')) {
        return;
    }

    $css = <<<'CSS'
.dcc-palette-tab .dcc-palette-tab__label{font-size:13px}
.dcc-palette-option__title{display:block;font-size:14px;font-weight:700;line-height:1.25;margin-bottom:4px}
.dcc-palette-option input:checked + .dcc-palette-option__card{border-width:4px !important;border-color:#4f7e78 !important;box-shadow:0 0 0 3px rgba(79,126,120,.12)}
.dcc-actions button[type="submit"]{display:block;margin:18px auto 0}
CSS;

    $js = <<<'JS'
(function () {
  const TOOL_SEL = '[data-dcc-tool]';
  const PAL_ORDER = ['beige_boho', 'pink_girl', 'blue_soft', 'sage_moss', 'yellow_sun', 'lavender_dream', 'apricot_soft', 'mint_cream', 'halloween', 'christmas', 'vintage_dusty', 'coastal'];
  const PAL_DESC = {
    beige_boho: 'Neutral boho shades: linen, sand, clay.',
    pink_girl: 'Soft pink shades for girly clipart packs.',
    blue_soft: 'Calm blue and sky-like shades.',
    sage_moss: 'Sage and mossy natural tones.',
    yellow_sun: 'Warm honey and yellow accents.',
    lavender_dream: 'Soft lavender pastel haze.',
    apricot_soft: 'Pastel apricot with warm neutrals.',
    mint_cream: 'Mint pastel shades with creamy accents.',
    halloween: 'Pumpkin, plum, charcoal and cream.',
    christmas: 'Fir, cranberry, gold and snow.',
    vintage_dusty: 'Dusty vintage blue, amber, red and brown.',
    coastal: 'Mint, sand and shell pink tones.'
  };
  const MODE_NAMES = { preset: 'Готовые', custom: 'Свои цвета', match_images: 'По рефам', auto: 'AI сам' };
  const qs = (s, r) => (r || document).querySelector(s);
  const qsa = (s, r) => Array.from((r || document).querySelectorAll(s));

  async function syncQuota(tool) {
    if (!window.DCC_TOOL) return;
    const fd = new FormData();
    fd.set('action', 'dccrp_get_quota');
    try {
      const res = await fetch(DCC_TOOL.ajaxUrl || '/wp-admin/admin-ajax.php', { method: 'POST', credentials: 'same-origin', body: fd });
      const payload = await res.json();
      if (!payload.success) return;
      const remainingEl = qs('[data-dcc-remaining]', tool);
      if (remainingEl) remainingEl.textContent = String(payload.data.remaining || 0);
      const quotaText = tool.querySelector('.dcc-quota span');
      if (quotaText) quotaText.textContent = 'из ' + String(payload.data.limit || 0) + ' кредитов осталось в текущем цикле';
      DCC_TOOL.remainingCredits = Number(payload.data.remaining || 0);
      DCC_TOOL.monthlyCredits = Number(payload.data.limit || 0);
    } catch (_e) {}
  }

  function patchPaletteUI(tool) {
    const variants = qs('[data-dcc-palette-variants]', tool);
    if (variants) {
      const cards = qsa('.dcc-palette-option', variants);
      const byValue = new Map(cards.map((node) => [qs('input', node) && qs('input', node).value, node]));
      variants.innerHTML = '';
      PAL_ORDER.forEach((key) => {
        const node = byValue.get(key);
        if (!node) return;
        const desc = qs('.dcc-palette-option__desc', node);
        if (desc && PAL_DESC[key]) desc.textContent = PAL_DESC[key];
        variants.appendChild(node);
      });
      cards.forEach((node) => {
        if (node.parentNode !== variants) variants.appendChild(node);
      });
      const defaultRadio = qs('input[value="beige_boho"]', variants);
      if (defaultRadio && !qs('input[name="preset_palette"]:checked', tool)) defaultRadio.checked = true;
    }
    qsa('.dcc-palette-tab', tool).forEach((tab) => {
      const input = qs('input', tab);
      const label = qs('.dcc-palette-tab__label', tab);
      if (input && label && MODE_NAMES[input.value]) label.textContent = MODE_NAMES[input.value];
    });
  }

  const boot = () => qsa(TOOL_SEL).forEach((tool) => {
    patchPaletteUI(tool);
    syncQuota(tool);
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true }); else boot();
})();
JS;

    wp_add_inline_style('dcc-frontend', $css);
    wp_add_inline_script('dcc-frontend', $js, 'after');
}, 100);

