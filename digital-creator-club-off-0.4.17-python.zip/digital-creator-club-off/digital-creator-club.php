<?php
/**
 * Plugin Name: Digital Creator Club
 * Description: Club tools for creating clipart ideas and digital product prompts with member quotas.
 * Version: 0.4.17
 * Author: OpenAI
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DCC_VERSION', '0.4.17');
define('DCC_PATH', plugin_dir_path(__FILE__));
define('DCC_URL', plugin_dir_url(__FILE__));
define('DCC_MAX_ITEMS_PER_GROUP', 30);

function dcc_tools_registry() {
    return array(
        'clipart-generator' => array(
            'title' => 'Генератор промтов для клипарта',
            'description' => 'Генерация структурированных идей и промтов для наборов цифровых товаров.',
            'shortcode' => '[dcc_clipart_generator]',
            'status' => 'Доступно',
            'available' => true,
        ),
        'bundle-planner' => array(
            'title' => 'Планировщик набора',
            'description' => 'Планирование набора по объектам, элементам и сценам.',
            'shortcode' => '[dcc_bundle_planner]',
            'status' => 'Доступно',
            'available' => true,
        ),
        'seo-helper' => array(
            'title' => 'Etsy SEO помощник',
            'description' => 'Черновики названий, тегов и описаний для цифровых товаров.',
            'shortcode' => '',
            'status' => 'Скоро',
            'available' => false,
        ),
    );
}

function dcc_render_club_services_menu() {
    if (empty($_SERVER['REQUEST_URI']) || strpos((string) $_SERVER['REQUEST_URI'], '/docs-category/club-services/') === false) {
        return;
    }

    $tools = dcc_tools_registry();
    ?>
    <aside class="dcc-club-services-menu" aria-label="Инструменты клуба">
        <div class="dcc-club-services-menu__inner">
            <p class="dcc-club-services-menu__label">Инструменты клуба</p>
            <h3>Сервисы клуба</h3>
            <nav class="dcc-club-services-menu__nav">
                <?php foreach ($tools as $tool_key => $tool) : ?>
                    <?php $link = !empty($tool['available']) ? dcc_tool_url($tool_key) : dcc_tools_base_url(); ?>
                    <a class="dcc-club-services-menu__link <?php echo !empty($tool['available']) ? 'is-available' : 'is-soon'; ?>" href="<?php echo esc_url($link); ?>">
                        <span class="dcc-club-services-menu__title"><?php echo esc_html($tool['title']); ?></span>
                        <span class="dcc-club-services-menu__status"><?php echo esc_html($tool['status']); ?></span>
                    </a>
                <?php endforeach; ?>
            </nav>
        </div>
    </aside>
    <?php
}

function dcc_inject_club_services_menu_css() {
    if (empty($_SERVER['REQUEST_URI']) || strpos((string) $_SERVER['REQUEST_URI'], '/docs-category/club-services/') === false) {
        return;
    }

    ?>
    <style>
        .dcc-club-services-menu {
            position: fixed;
            top: 140px;
            left: 24px;
            width: 260px;
            z-index: 40;
        }
        .dcc-club-services-menu__inner {
            background: #fff;
            border: 1px solid rgba(191, 165, 136, 0.28);
            border-radius: 18px;
            box-shadow: 0 14px 30px rgba(64, 44, 21, 0.08);
            padding: 18px;
        }
        .dcc-club-services-menu__label {
            margin: 0 0 6px;
            font-size: 12px;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: #8b6d57;
        }
        .dcc-club-services-menu h3 {
            margin: 0 0 14px;
            font-size: 18px;
            line-height: 1.2;
        }
        .dcc-club-services-menu__nav {
            display: grid;
            gap: 10px;
        }
        .dcc-club-services-menu__link {
            display: flex;
            flex-direction: column;
            gap: 4px;
            padding: 12px 14px;
            border-radius: 14px;
            border: 1px solid rgba(191, 165, 136, 0.18);
            text-decoration: none;
            color: inherit;
            background: #faf7f3;
        }
        .dcc-club-services-menu__link.is-available:hover {
            border-color: #b76a71;
            box-shadow: 0 8px 18px rgba(183, 106, 113, 0.12);
        }
        .dcc-club-services-menu__title {
            font-weight: 700;
            font-size: 14px;
        }
        .dcc-club-services-menu__status {
            font-size: 12px;
            color: #8b6d57;
        }
        @media (max-width: 1200px) {
            .dcc-club-services-menu {
                position: static;
                width: auto;
                margin: 20px 0;
            }
        }
    </style>
    <?php
}
add_action('wp_body_open', 'dcc_render_club_services_menu');
add_action('wp_head', 'dcc_inject_club_services_menu_css');
remove_action('wp_body_open', 'dcc_render_club_services_menu');
remove_action('wp_head', 'dcc_inject_club_services_menu_css');

function dcc_get_tools_directory_items() {
    $tools = dcc_tools_registry();
    $items = array();

    foreach ($tools as $tool_key => $tool) {
        $available = !empty($tool['available']);
        $items[] = array(
            'key' => $tool_key,
            'title' => $tool['title'],
            'description' => $tool['description'],
            'status' => $tool['status'],
            'available' => $available,
            'url' => $available ? dcc_tool_url($tool_key) : dcc_tools_base_url(),
        );
    }

    return $items;
}

function dcc_render_tools_directory_block($label = '??????????? ?????', $title = '??????? ?????') {
    $items = dcc_get_tools_directory_items();

    ob_start();
    ?>
    <div class="dcc-services-inline-tools" data-dcc-tools-inline aria-label="<?php echo esc_attr($label); ?>">
        <p class="dcc-services-inline-tools__label"><?php echo esc_html($title); ?></p>
        <div class="dcc-services-inline-tools__list">
            <?php foreach ($items as $item) : ?>
                <?php if (!empty($item['available'])) : ?>
                    <a class="dcc-services-inline-tools__link is-available" href="<?php echo esc_url($item['url']); ?>">
                        <?php echo esc_html($item['title']); ?>
                    </a>
                <?php else : ?>
                    <span class="dcc-services-inline-tools__link is-soon" aria-disabled="true">
                        <?php echo esc_html($item['title']); ?>
                    </span>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
    <?php

    return ob_get_clean();
}

// Auto-injection into BetterDocs service lists is disabled.

function dcc_default_settings() {
    return array(
        'monthly_credits' => 100,
        'request_cost_clipart_generator' => 1,
        'request_cost_bundle_planner' => 1,
        'request_cost_seo_helper' => 1,
        'max_groups' => 5,
        'require_login' => 1,
        'openrouter_api_key' => '',
        'model_clipart_generator' => 'openai/gpt-4o-mini',
        'temperature_clipart_generator' => 0.7,
        'max_tokens_clipart_generator' => 1200,
        'model_bundle_planner' => 'openai/gpt-4o-mini',
        'temperature_bundle_planner' => 0.7,
        'max_tokens_bundle_planner' => 1200,
        'model_seo_helper' => 'openai/gpt-4o-mini',
        'temperature_seo_helper' => 0.5,
        'max_tokens_seo_helper' => 1400,
    );
}

function dcc_get_settings() {
    $settings = wp_parse_args(get_option('dcc_settings', array()), dcc_default_settings());
    $settings['max_groups'] = max(1, min(15, (int) ($settings['max_groups'] ?? 5)));
    foreach (array('clipart_generator', 'bundle_planner', 'seo_helper') as $tool_key) {
        $cost_key = 'request_cost_' . $tool_key;
        $settings[$cost_key] = max(1, (int) ($settings[$cost_key] ?? 1));
    }
    return $settings;
}

function dcc_activate() {
    if (!get_option('dcc_settings')) {
        add_option('dcc_settings', dcc_default_settings());
    }
    update_option('dcc_settings_schema_version', '2');
}
register_activation_hook(__FILE__, 'dcc_activate');

function dcc_maybe_migrate_settings() {
    $schema_version = (string) get_option('dcc_settings_schema_version', '');
    if ($schema_version === '2') {
        return;
    }

    $current = get_option('dcc_settings', array());
    if (!is_array($current)) {
        $current = array();
    }

    $defaults = dcc_default_settings();
    $migrated = wp_parse_args($current, $defaults);

    // Legacy -> current keys.
    if (isset($current['credits_per_item']) && !isset($current['request_cost_clipart_generator'])) {
        $migrated['request_cost_clipart_generator'] = max(1, (int) $current['credits_per_item']);
    }
    if (!isset($migrated['request_cost_bundle_planner'])) {
        $migrated['request_cost_bundle_planner'] = 1;
    }
    if (!isset($migrated['request_cost_seo_helper'])) {
        $migrated['request_cost_seo_helper'] = 1;
    }
    if (isset($current['monthly_credits_clipart_generator']) && !isset($current['monthly_credits'])) {
        $migrated['monthly_credits'] = max(1, (int) $current['monthly_credits_clipart_generator']);
    }

    // Remove unused legacy keys from stored option.
    unset(
        $migrated['credits_per_item'],
        $migrated['max_items_per_group'],
        $migrated['monthly_credits_clipart_generator'],
        $migrated['monthly_credits_bundle_planner'],
        $migrated['monthly_credits_seo_helper']
    );

    update_option('dcc_settings', dcc_sanitize_settings($migrated));
    update_option('dcc_settings_schema_version', '2');
}
add_action('init', 'dcc_maybe_migrate_settings');

function dcc_tool_setting_suffix($tool_id) {
    $map = array(
        'clipart-generator' => 'clipart_generator',
        'bundle-planner' => 'bundle_planner',
        'seo-helper' => 'seo_helper',
    );
    return $map[$tool_id] ?? 'clipart_generator';
}

function dcc_get_tool_request_cost($tool_id, $settings = null) {
    if (!is_array($settings)) {
        $settings = dcc_get_settings();
    }
    $suffix = dcc_tool_setting_suffix($tool_id);
    $key = 'request_cost_' . $suffix;
    return max(1, (int) ($settings[$key] ?? 1));
}

function dcc_user_cycle_day($user_id) {
    $day = (int) get_user_meta($user_id, 'dcc_cycle_day', true);
    if ($day < 1 || $day > 31) {
        $day = 1;
    }
    return $day;
}

function dcc_cycle_start_for($timestamp, $cycle_day) {
    $cycle_day = max(1, min(31, (int) $cycle_day));
    $now_year = (int) wp_date('Y', $timestamp);
    $now_month = (int) wp_date('n', $timestamp);
    $now_day = (int) wp_date('j', $timestamp);
    $days_in_month = (int) wp_date('t', $timestamp);

    $current_month_start_day = min($cycle_day, $days_in_month);
    if ($now_day >= $current_month_start_day) {
        $start_day = $current_month_start_day;
        $start_month = $now_month;
        $start_year = $now_year;
    } else {
        $prev_month_ts = strtotime('-1 month', $timestamp);
        $start_month = (int) wp_date('n', $prev_month_ts);
        $start_year = (int) wp_date('Y', $prev_month_ts);
        $start_day = min($cycle_day, (int) wp_date('t', $prev_month_ts));
    }

    return sprintf('%04d-%02d-%02d', $start_year, $start_month, $start_day);
}

function dcc_get_user_tool_limit($user_id, $tool_id) {
    $settings = dcc_get_settings();
    $base_limit = max(1, (int) ($settings['monthly_credits'] ?? 100));
    $bonus = (int) get_user_meta($user_id, 'dcc_bonus_all_tools', true);
    return max(1, $base_limit + $bonus);
}

function dcc_ensure_user_quota($user_id, $tool_id = 'clipart-generator') {
    $now = current_time('timestamp');
    $window = dcc_cycle_start_for($now, dcc_user_cycle_day($user_id));
    $limit = dcc_get_user_tool_limit($user_id, $tool_id);
    $window_key = 'dcc_quota_window';
    $limit_key = 'dcc_credits_limit';
    $remaining_key = 'dcc_credits_remaining';

    $stored_window = (string) get_user_meta($user_id, $window_key, true);
    $stored_remaining = get_user_meta($user_id, $remaining_key, true);

    if ($stored_window !== $window || $stored_remaining === '') {
        update_user_meta($user_id, $window_key, $window);
        update_user_meta($user_id, $limit_key, $limit);
        update_user_meta($user_id, $remaining_key, $limit);
    } else {
        $stored_limit = (int) get_user_meta($user_id, $limit_key, true);
        if ($stored_limit !== $limit) {
            $delta = $limit - $stored_limit;
            $new_remaining = max(0, (int) $stored_remaining + $delta);
            update_user_meta($user_id, $limit_key, $limit);
            update_user_meta($user_id, $remaining_key, $new_remaining);
        }
    }

    return array(
        'limit' => (int) get_user_meta($user_id, $limit_key, true),
        'remaining' => (int) get_user_meta($user_id, $remaining_key, true),
        'window' => (string) get_user_meta($user_id, $window_key, true),
        'cycle_day' => dcc_user_cycle_day($user_id),
    );
}

function dcc_register_assets() {
    wp_register_style('dcc-frontend', DCC_URL . 'assets/frontend.css', array(), DCC_VERSION);
    wp_register_script('dcc-frontend', DCC_URL . 'assets/frontend.js', array(), DCC_VERSION, true);
}
add_action('wp_enqueue_scripts', 'dcc_register_assets');

function dcc_register_query_vars($vars) {
    $vars[] = 'dcc_tool';
    return $vars;
}
add_filter('query_vars', 'dcc_register_query_vars');

function dcc_admin_menu() {
    add_options_page(
        'Digital Creator Club',
        'Digital Creator Club',
        'manage_options',
        'dcc-settings',
        'dcc_render_settings_page'
    );
}
add_action('admin_menu', 'dcc_admin_menu');

function dcc_register_settings() {
    register_setting('dcc_settings_group', 'dcc_settings', 'dcc_sanitize_settings');

    add_settings_section(
        'dcc_main',
        'Club limits',
        function () {
            echo '<p>Default quota and generator limits for new members.</p>';
        },
        'dcc-settings'
    );

    $main_fields = array(
        'monthly_credits' => 'Monthly credits',
        'max_groups' => 'Max groups per pack',
        'require_login' => 'Require login',
        'openrouter_api_key' => 'OpenRouter API key',
    );

    foreach ($main_fields as $key => $label) {
        add_settings_field(
            'dcc_' . $key,
            $label,
            'dcc_render_setting_field',
            'dcc-settings',
            'dcc_main',
            array('key' => $key)
        );
    }

    add_settings_section(
        'dcc_models',
        'Model settings by tool',
        function () {
            echo '<p>Each tool has its own model, temperature, and max tokens.</p>';
        },
        'dcc-settings'
    );

    $tool_fields = array(
        'request_cost_clipart_generator' => 'Clipart Prompt Generator: request cost (credits)',
        'model_clipart_generator' => 'Clipart Prompt Generator: model',
        'temperature_clipart_generator' => 'Clipart Prompt Generator: temperature',
        'max_tokens_clipart_generator' => 'Clipart Prompt Generator: max output tokens',
        'request_cost_bundle_planner' => 'Bundle Planner: request cost (credits)',
        'model_bundle_planner' => 'Bundle Planner: model',
        'temperature_bundle_planner' => 'Bundle Planner: temperature',
        'max_tokens_bundle_planner' => 'Bundle Planner: max output tokens',
        'request_cost_seo_helper' => 'SEO Helper: request cost (credits)',
        'model_seo_helper' => 'SEO Helper: model',
        'temperature_seo_helper' => 'SEO Helper: temperature',
        'max_tokens_seo_helper' => 'SEO Helper: max output tokens',
    );

    foreach ($tool_fields as $key => $label) {
        add_settings_field(
            'dcc_' . $key,
            $label,
            'dcc_render_setting_field',
            'dcc-settings',
            'dcc_models',
            array('key' => $key)
        );
    }
}
add_action('admin_init', 'dcc_register_settings');

function dcc_sanitize_settings($input) {
    $defaults = dcc_default_settings();

    return array(
        'monthly_credits' => max(1, (int) ($input['monthly_credits'] ?? $defaults['monthly_credits'])),
        'max_groups' => max(1, min(15, (int) ($input['max_groups'] ?? $defaults['max_groups']))),
        'require_login' => !empty($input['require_login']) ? 1 : 0,
        'openrouter_api_key' => sanitize_text_field($input['openrouter_api_key'] ?? ''),
        'request_cost_clipart_generator' => max(1, (int) ($input['request_cost_clipart_generator'] ?? $defaults['request_cost_clipart_generator'])),
        'model_clipart_generator' => sanitize_text_field($input['model_clipart_generator'] ?? $defaults['model_clipart_generator']),
        'temperature_clipart_generator' => min(2, max(0, (float) ($input['temperature_clipart_generator'] ?? $defaults['temperature_clipart_generator']))),
        'max_tokens_clipart_generator' => max(300, (int) ($input['max_tokens_clipart_generator'] ?? $defaults['max_tokens_clipart_generator'])),
        'request_cost_bundle_planner' => max(1, (int) ($input['request_cost_bundle_planner'] ?? $defaults['request_cost_bundle_planner'])),
        'model_bundle_planner' => sanitize_text_field($input['model_bundle_planner'] ?? $defaults['model_bundle_planner']),
        'temperature_bundle_planner' => min(2, max(0, (float) ($input['temperature_bundle_planner'] ?? $defaults['temperature_bundle_planner']))),
        'max_tokens_bundle_planner' => max(300, (int) ($input['max_tokens_bundle_planner'] ?? $defaults['max_tokens_bundle_planner'])),
        'request_cost_seo_helper' => max(1, (int) ($input['request_cost_seo_helper'] ?? $defaults['request_cost_seo_helper'])),
        'model_seo_helper' => sanitize_text_field($input['model_seo_helper'] ?? $defaults['model_seo_helper']),
        'temperature_seo_helper' => min(2, max(0, (float) ($input['temperature_seo_helper'] ?? $defaults['temperature_seo_helper']))),
        'max_tokens_seo_helper' => max(300, (int) ($input['max_tokens_seo_helper'] ?? $defaults['max_tokens_seo_helper'])),
    );
}

function dcc_render_setting_field($args) {
    $settings = dcc_get_settings();
    $key = $args['key'];
    $value = $settings[$key] ?? '';

    if ($key === 'require_login') {
        printf(
            '<label><input type="checkbox" name="dcc_settings[%1$s]" value="1" %2$s> Restrict tool access to logged-in users</label>',
            esc_attr($key),
            checked(1, (int) $value, false)
        );
        return;
    }

    if ($key === 'openrouter_api_key') {
        printf(
            '<input type="password" class="regular-text" name="dcc_settings[%1$s]" value="%2$s" autocomplete="off" placeholder="sk-or-...">',
            esc_attr($key),
            esc_attr($value)
        );
        return;
    }

    if (strpos($key, 'model_') === 0) {
        printf(
            '<input type="text" class="regular-text" name="dcc_settings[%1$s]" value="%2$s" placeholder="openai/gpt-4o-mini">',
            esc_attr($key),
            esc_attr($value)
        );
        return;
    }

    if (strpos($key, 'temperature_') === 0) {
        printf(
            '<input type="number" min="0" max="2" step="0.1" class="regular-text" name="dcc_settings[%1$s]" value="%2$s">',
            esc_attr($key),
            esc_attr($value)
        );
        return;
    }

    if (strpos($key, 'max_tokens_') === 0) {
        printf(
            '<input type="number" min="300" step="1" class="regular-text" name="dcc_settings[%1$s]" value="%2$s">',
            esc_attr($key),
            esc_attr($value)
        );
        return;
    }

    $max_attr = '';
    if ($key === 'max_groups') {
        $max_attr = ' max="15"';
    }

    printf(
        '<input type="number" min="1"%3$s class="regular-text" name="dcc_settings[%1$s]" value="%2$s">',
        esc_attr($key),
        esc_attr($value),
        $max_attr
    );
}

function dcc_render_settings_page() {
    $tool_sections = array(
        'clipart_generator' => 'Генератор промтов для клипарта',
        'bundle_planner' => 'Планировщик набора',
        'seo_helper' => 'Etsy SEO помощник',
    );
    ?>
    <div class="wrap">
        <h1>Digital Creator Club</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('dcc_settings_group');
            ?>
            <h2>Общие настройки</h2>
            <style>
                .dcc-main-settings tr:nth-child(3),
                .dcc-main-settings tr.dcc-hidden-row { display: none; }
            </style>
            <table class="form-table dcc-main-settings" role="presentation">
                <tr>
                    <th scope="row">Ключ OpenRouter</th>
                    <td><?php dcc_render_setting_field(array('key' => 'openrouter_api_key')); ?></td>
                </tr>
                <tr>
                    <th scope="row">Месячный лимит по умолчанию на пользователя</th>
                    <td><?php dcc_render_setting_field(array('key' => 'monthly_credits')); ?></td>
                </tr>
                <tr>
                    <th scope="row">Стоимость одного промта (в кредитах)</th>
                    <td><?php /* moved to per-tool settings */ ?></td>
                </tr>
                <tr>
                    <th scope="row">Макс. групп в одном наборе</th>
                    <td><?php dcc_render_setting_field(array('key' => 'max_groups')); ?></td>
                </tr>
                <tr class="dcc-hidden-row">
                    <th scope="row">Макс. промтов в одной группе</th>
                    <td><?php /* fixed in code */ ?></td>
                </tr>
                <tr>
                    <th scope="row">Только для авторизованных</th>
                    <td><?php dcc_render_setting_field(array('key' => 'require_login')); ?></td>
                </tr>
            </table>

            <hr />
            <?php foreach ($tool_sections as $suffix => $title) : ?>
                <h2><?php echo esc_html($title); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Стоимость 1 запроса (кредиты)</th>
                        <td><?php dcc_render_setting_field(array('key' => 'request_cost_' . $suffix)); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Модель</th>
                        <td><?php dcc_render_setting_field(array('key' => 'model_' . $suffix)); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Temperature</th>
                        <td><?php dcc_render_setting_field(array('key' => 'temperature_' . $suffix)); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Max output tokens</th>
                        <td><?php dcc_render_setting_field(array('key' => 'max_tokens_' . $suffix)); ?></td>
                    </tr>
                </table>
                <hr />
            <?php endforeach; ?>
            <?php
            submit_button();
            ?>
        </form>
        <p>Use shortcode: <code>[dcc_clipart_generator]</code></p>
    </div>
    <?php
}

function dcc_render_user_quota_fields($user) {
    if (!current_user_can('manage_options')) {
        return;
    }

    $cycle_day = dcc_user_cycle_day($user->ID);
    $bonus_all = (int) get_user_meta($user->ID, 'dcc_bonus_all_tools', true);
    ?>
    <h2>Digital Creator Club</h2>
    <table class="form-table" role="presentation">
        <tr>
            <th><label for="dcc_cycle_day">Credit cycle start day</label></th>
            <td>
                <input type="number" min="1" max="31" name="dcc_cycle_day" id="dcc_cycle_day" value="<?php echo esc_attr((string) $cycle_day); ?>" class="regular-text" />
                <p class="description">Allowed values: 1-31. If a month has fewer days, the cycle starts on the last day of that month.</p>
            </td>
        </tr>
        <tr>
            <th><label for="dcc_bonus_all_tools">Bonus credits (all tools)</label></th>
            <td>
                <input type="number" step="1" name="dcc_bonus_all_tools" id="dcc_bonus_all_tools" value="<?php echo esc_attr((string) $bonus_all); ?>" class="regular-text" />
            </td>
        </tr>
    </table>
    <?php
}
add_action('show_user_profile', 'dcc_render_user_quota_fields');
add_action('edit_user_profile', 'dcc_render_user_quota_fields');

function dcc_save_user_quota_fields($user_id) {
    if (!current_user_can('manage_options')) {
        return;
    }

    if (!isset($_POST['dcc_cycle_day'])) {
        return;
    }

    $cycle_day = (int) $_POST['dcc_cycle_day'];
    $cycle_day = max(1, min(31, $cycle_day));
    update_user_meta($user_id, 'dcc_cycle_day', $cycle_day);

    $bonus_all = isset($_POST['dcc_bonus_all_tools']) ? (int) $_POST['dcc_bonus_all_tools'] : 0;
    update_user_meta($user_id, 'dcc_bonus_all_tools', $bonus_all);
}
add_action('personal_options_update', 'dcc_save_user_quota_fields');
add_action('edit_user_profile_update', 'dcc_save_user_quota_fields');

function dcc_normalize_groups($groups) {
    $normalized = array();

    if (!is_array($groups)) {
        return $normalized;
    }

    foreach ($groups as $group) {
        $name = sanitize_text_field($group['name'] ?? '');
        $count = max(1, (int) ($group['count'] ?? 1));

        if ($name === '') {
            continue;
        }

        $normalized[] = array(
            'name' => $name,
            'count' => $count,
        );
    }

    return $normalized;
}

function dcc_motif_pool() {
    return array(
        'mushroom', 'flower', 'star', 'rabbit', 'cloud', 'bow', 'berry', 'leaf',
        'moon', 'bird', 'acorn', 'teacup', 'pumpkin', 'snail', 'butterfly'
    );
}

function dcc_default_group_rows() {
    return array(
        array('name' => 'объект', 'count' => 3),
        array('name' => 'декоративные элементы', 'count' => 3),
        array('name' => 'бордюры / рамки', 'count' => 3),
    );
}

function dcc_adjective_pool() {
    return array(
        'tiny', 'rounded', 'gentle', 'cozy', 'soft', 'delicate', 'playful', 'minimal',
        'sweet', 'whimsical', 'calm', 'friendly', 'dreamy', 'light', 'storybook'
    );
}

function dcc_palette_options() {
    return array(
        'beige_boho' => array(
            'label' => '??????? ????',
            'description' => '??????????? boho-???????: ???, ?????, ?????.',
            'swatches' => array('#EFE7D8', '#E3D2BA', '#D2B494', '#BD9876', '#A87F61'),
        ),
        'pink_girl' => array(
            'label' => '?????-???????',
            'description' => '?????? ??????? ??????? ??? ???????? ???????.',
            'swatches' => array('#F6DDE3', '#EFC7D3', '#E3AFC2', '#CF8FA6', '#B66F85'),
        ),
        'blue_soft' => array(
            'label' => '??????? ??????',
            'description' => '????????? ??????? ? ???????? ???????.',
            'swatches' => array('#D8EAF4', '#BED9EA', '#9FC3DE', '#7EA8CB', '#CFC9C2'),
        ),
        'sage_moss' => array(
            'label' => '?????? ? ???',
            'description' => '???????, ????????? ? ??????? ????.',
            'swatches' => array('#DDE4D8', '#C7D2C0', '#A9BC9E', '#879E7A', '#D3CCBC'),
        ),
        'yellow_sun' => array(
            'label' => '????????? ??????',
            'description' => '?????? ??????? ? ?????? ???????.',
            'swatches' => array('#F8EFBF', '#F2E59A', '#E9D86E', '#D6C457', '#ECE3CD'),
        ),
        'lavender_dream' => array(
            'label' => '?????????? ???',
            'description' => '??????? ??????? ? ?????? ??????.',
            'swatches' => array('#E1D8EE', '#CEC0E3', '#B7A3D6', '#E3DCE8', '#F1EAF2'),
        ),
        'apricot_soft' => array(
            'label' => '??????????? ??????',
            'description' => '?????????? ??????? ? ??????? ?????? ????????.',
            'swatches' => array('#F7E4CF', '#F1D0AE', '#E9B988', '#DDA16C', '#E7DCCE'),
        ),
        'mint_cream' => array(
            'label' => '???? ? ????',
            'description' => '?????? ??????? ? ????????? ?????????.',
            'swatches' => array('#D7E8E2', '#BEE0D2', '#97D0B9', '#CFC8A1', '#E3D18B'),
        ),
        'halloween' => array(
            'label' => '????????',
            'description' => '?????????, ????????, ???????? ? ????????.',
            'swatches' => array('#FF9A3D', '#7F4A88', '#2F2B35', '#C58A57', '#F6E9D1'),
        ),
        'christmas' => array(
            'label' => '?????????',
            'description' => '???, ??????, ?????? ? ????.',
            'swatches' => array('#1F6A4C', '#B33A4A', '#D9B562', '#F2EEE6', '#DDD7CD'),
        ),
        'vintage_dusty' => array(
            'label' => '?????? ???????????',
            'description' => '??????????? ?????, ????????, ??????? ? ??????????.',
            'swatches' => array('#6F8898', '#C9A05E', '#A76A64', '#8A6C57', '#D9C7A6'),
        ),
        'coastal' => array(
            'label' => '???????',
            'description' => '????, ????? ? ?????????? ???????.',
            'swatches' => array('#BFDCD1', '#DCCEA2', '#BFD3E2', '#E5C5C9', '#DDD8CC'),
        ),
        'custom' => array(
            'label' => '????',
            'description' => '??????? ???? ???????? ?????? ??? hex-????.',
            'swatches' => array('#EFE7DF', '#D9D1C7', '#BFAE9D', '#9E8C7C', '#7F6C5E'),
        ),
        'auto' => array(
            'label' => 'AI ?????',
            'description' => '?????? ???? ???????? ?????? ??????? ??? ????.',
            'swatches' => array('#F6EFE8', '#E7D4BE', '#D3B3A5', '#B98A7D', '#8F6F64'),
        ),
        'match_images' => array(
            'label' => '?? ?????',
            'description' => '??????????????? ?? ??????????? ?????????.',
            'swatches' => array('#E8F2EF', '#D2E7DC', '#A9CDBD', '#7FA891', '#CFD7D1'),
        ),
        'none' => array(
            'label' => '??? ???????',
            'description' => '?? ??????????? ????? ? ??????.',
            'swatches' => array('#F4F1ED', '#E7E0D8', '#D0C7BC', '#B9AEA0', '#9F9284'),
        ),
    );
}

function dcc_palette_summary($palette_key, $custom_colors = '') {
    $options = dcc_palette_options();

    if ($palette_key === 'custom') {
        $custom_colors = trim(sanitize_textarea_field($custom_colors));

        if ($custom_colors !== '') {
            return 'custom colors: ' . $custom_colors;
        }

        return 'custom colors chosen by the user';
    }

    if ($palette_key === 'auto' || !isset($options[$palette_key])) {
        return 'palette chosen by AI';
    }

    if ($palette_key === 'match_images') {
        return 'palette matched to inspiration images';
    }

    if ($palette_key === 'none') {
        return 'no palette guidance';
    }

    $swatches = implode(', ', $options[$palette_key]['swatches']);

    return $options[$palette_key]['label'] . ' palette: ' . $swatches;
}



function dcc_palette_phrase_for_prompt($palette_key, $custom_colors = '') {
    $options = dcc_palette_options();
    if ($palette_key === 'custom') {
        $custom_colors = trim(sanitize_textarea_field($custom_colors));
        return $custom_colors !== '' ? $custom_colors : 'soft custom palette';
    }
    if ($palette_key === 'match_images') {
        return 'palette derived from reference images';
    }
    if ($palette_key === 'auto' || !isset($options[$palette_key])) {
        return 'cohesive soft pastel palette';
    }
    if ($palette_key === 'none') {
        return 'harmonious natural pastel palette';
    }
    return strtolower($options[$palette_key]['label']) . ' palette';
}

function dcc_palette_instruction_text($palette_key, $custom_colors = '') {
    $options = dcc_palette_options();
    if ($palette_key === 'custom') {
        $custom_colors = trim(sanitize_textarea_field($custom_colors));
        if ($custom_colors !== '') {
            return 'Use only user custom colors: ' . $custom_colors . '. Keep all prompts within this color family.';
        }
        return 'Use only a restrained custom color palette selected by the user.';
    }
    if ($palette_key === 'match_images') {
        return 'Derive palette from uploaded reference images and keep it consistent across all prompts.';
    }
    if ($palette_key === 'auto' || !isset($options[$palette_key])) {
        return 'Choose a cohesive soft palette that is consistent across all prompts in the set.';
    }
    if ($palette_key === 'none') {
        return 'No fixed palette is required, but keep colors harmonious across the whole set.';
    }
    $swatches = implode(', ', $options[$palette_key]['swatches']);
    return 'Use this preset palette only: ' . $swatches . '. Keep all prompts in this exact palette family.';
}

function dcc_extract_reference_image_data($file) {
    if (!is_array($file) || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        return null;
    }
    if (!empty($file['error']) && (int) $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }

    $tmp = (string) $file['tmp_name'];
    $size = @getimagesize($tmp);
    if (!$size || empty($size['mime']) || strpos((string) $size['mime'], 'image/') !== 0) {
        return null;
    }

    $raw = @file_get_contents($tmp);
    if ($raw === false || $raw === '') {
        return null;
    }
    if (strlen($raw) > 1500000) {
        return null;
    }

    $palette = array();
    if (function_exists('imagecreatefromstring')) {
        $im = @imagecreatefromstring($raw);
        if ($im !== false) {
            $w = imagesx($im);
            $h = imagesy($im);
            $bins = array();
            $step_x = max(1, (int) floor($w / 24));
            $step_y = max(1, (int) floor($h / 24));
            for ($y = 0; $y < $h; $y += $step_y) {
                for ($x = 0; $x < $w; $x += $step_x) {
                    $rgb = imagecolorat($im, $x, $y);
                    $r = ($rgb >> 16) & 0xFF;
                    $g = ($rgb >> 8) & 0xFF;
                    $b = $rgb & 0xFF;
                    $qr = (int) (round($r / 32) * 32);
                    $qg = (int) (round($g / 32) * 32);
                    $qb = (int) (round($b / 32) * 32);
                    $key = sprintf('%02x%02x%02x', max(0, min(255, $qr)), max(0, min(255, $qg)), max(0, min(255, $qb)));
                    $bins[$key] = ($bins[$key] ?? 0) + 1;
                }
            }
            imagedestroy($im);
            arsort($bins);
            $palette = array_slice(array_map(function ($hex) { return '#' . $hex; }, array_keys($bins)), 0, 6);
        }
    }

    return array(
        'name' => sanitize_file_name((string) ($file['name'] ?? 'reference')),
        'mime' => (string) $size['mime'],
        'width' => (int) ($size[0] ?? 0),
        'height' => (int) ($size[1] ?? 0),
        'palette' => $palette,
        'data_url' => 'data:' . (string) $size['mime'] . ';base64,' . base64_encode($raw),
    );
}

function dcc_collect_reference_images_from_request() {
    $images = array();
    for ($i = 1; $i <= 4; $i++) {
        $key = 'inspiration_image_' . $i;
        if (!isset($_FILES[$key])) {
            continue;
        }
        $image = dcc_extract_reference_image_data($_FILES[$key]);
        if ($image) {
            $images[] = $image;
        }
    }
    return $images;
}

function dcc_build_reference_brief_via_openrouter($reference_images, $api_key, $model_id) {
    if (empty($reference_images)) {
        return '';
    }

    $content = array(
        array(
            'type' => 'text',
            'text' => 'Analyze the reference images for a clipart set. Return strict JSON only: {"style_notes":["..."],"motifs":["..."],"color_words":["..."]}. Keep notes short and visual.',
        ),
    );

    foreach ($reference_images as $image) {
        if (empty($image['data_url'])) {
            continue;
        }
        $content[] = array(
            'type' => 'image_url',
            'image_url' => array('url' => $image['data_url']),
        );
    }

    $response = wp_remote_post(
        'https://openrouter.ai/api/v1/chat/completions',
        array(
            'timeout' => 70,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
                'HTTP-Referer' => home_url('/'),
                'X-Title' => 'Digital Creator Club',
            ),
            'body' => wp_json_encode(array(
                'model' => $model_id,
                'temperature' => 0.2,
                'max_tokens' => 350,
                'messages' => array(
                    array('role' => 'system', 'content' => 'You are a visual style analyst for clipart prompt generation.'),
                    array('role' => 'user', 'content' => $content),
                ),
            )),
        )
    );

    if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) >= 300) {
        $name_tokens = array();
        foreach ($reference_images as $img) {
            $name = strtolower((string) ($img['name'] ?? ''));
            $name = preg_replace('/[^a-z0-9]+/', ' ', $name);
            $parts = array_filter(array_map('trim', explode(' ', (string) $name)));
            foreach ($parts as $part) {
                if (strlen($part) >= 3) {
                    $name_tokens[] = $part;
                }
            }
        }
        $name_tokens = array_slice(array_values(array_unique($name_tokens)), 0, 8);
        if (!empty($name_tokens)) {
            return 'Reference filename cues: ' . implode(', ', $name_tokens);
        }
        return '';
    }

    $json = json_decode((string) wp_remote_retrieve_body($response), true);
    $text = (string) ($json['choices'][0]['message']['content'] ?? '');
    $parsed = dcc_openrouter_extract_json($text);
    if (!is_array($parsed)) {
        return '';
    }

    $style_notes = array_slice(array_filter(array_map('sanitize_text_field', (array) ($parsed['style_notes'] ?? array()))), 0, 6);
    $motifs = array_slice(array_filter(array_map('sanitize_text_field', (array) ($parsed['motifs'] ?? array()))), 0, 8);
    $color_words = array_slice(array_filter(array_map('sanitize_text_field', (array) ($parsed['color_words'] ?? array()))), 0, 8);

    $parts = array();
    if (!empty($style_notes)) {
        $parts[] = 'Reference style notes: ' . implode('; ', $style_notes);
    }
    if (!empty($motifs)) {
        $parts[] = 'Reference motifs: ' . implode(', ', $motifs);
    }
    if (!empty($color_words)) {
        $parts[] = 'Reference color words: ' . implode(', ', $color_words);
    }

    return implode(' | ', $parts);
}

function dcc_generate_groups($input) {
    $theme = sanitize_text_field($input['theme'] ?? 'untitled clipart pack');
    $template = sanitize_textarea_field($input['template'] ?? '');
    $rules = sanitize_textarea_field($input['rules'] ?? '');
    $mode = in_array(($input['mode'] ?? 'prompts'), array('ideas', 'prompts'), true) ? $input['mode'] : 'prompts';
    $palette_key = sanitize_text_field($input['palette'] ?? 'auto');
    $custom_colors = sanitize_text_field($input['custom_colors'] ?? '');
    $palette = dcc_palette_summary($palette_key, $custom_colors);
    $groups = dcc_normalize_groups($input['groups'] ?? array());

    $adjectives = dcc_adjective_pool();
    $motifs = dcc_motif_pool();
    $results = array();

    foreach ($groups as $group_index => $group) {
        $items = array();
        $group_name = ucfirst(trim($group['name']));

        for ($i = 0; $i < $group['count']; $i++) {
            $seed = abs(crc32($theme . '|' . $group['name'] . '|' . $i));
            $adjective = $adjectives[$seed % count($adjectives)];
            $motif = $motifs[($seed + $group_index) % count($motifs)];
            $title = sprintf('%s %s %d', ucfirst($adjective), rtrim($group_name, 's'), $i + 1);

            if ($mode === 'ideas') {
                $prompt = sprintf(
                    '%s idea for %s with %s %s and %s',
                    $theme,
                    strtolower($group_name),
                    $adjective,
                    $motif,
                    $palette
                );
            } else {
                $prompt = trim(
                    implode(', ', array_filter(array(
                        $template,
                        sprintf('%s for a %s', $adjective . ' ' . $motif, $theme),
                        'color palette: ' . $palette,
                        $rules !== '' ? 'rules: ' . $rules : '',
                    )))
                );
            }

            $items[] = array(
                'title' => $title,
                'prompt' => $prompt,
            );
        }

        $results[] = array(
            'name' => $group_name,
            'items' => $items,
        );
    }

    return $results;
}

function dcc_generate_bundle_plan($input) {
    $theme = sanitize_text_field($input['theme'] ?? 'untitled bundle');
    $audience = sanitize_text_field($input['audience'] ?? 'club members');
    $bundle_type = sanitize_text_field($input['bundle_type'] ?? 'clipart bundle');
    $item_count = max(3, min(12, (int) ($input['item_count'] ?? 6)));
    $style = sanitize_text_field($input['style'] ?? 'cute watercolor');
    $must_include = sanitize_textarea_field($input['must_include'] ?? '');

    $motifs = dcc_motif_pool();
    $adjectives = dcc_adjective_pool();
    $sections = array();
    $bundle_items = array();

    for ($i = 0; $i < $item_count; $i++) {
        $seed = abs(crc32($theme . '|' . $bundle_type . '|' . $i));
        $motif = $motifs[$seed % count($motifs)];
        $adjective = $adjectives[($seed + 3) % count($adjectives)];
        $bundle_items[] = sprintf('%s %s %s', ucfirst($adjective), $motif, $i + 1);
    }

    $sections[] = array(
        'title' => 'Theme',
        'body' => $theme,
    );
    $sections[] = array(
        'title' => 'Audience',
        'body' => $audience,
    );
    $sections[] = array(
        'title' => 'Style',
        'body' => $style,
    );
    $sections[] = array(
        'title' => 'Bundle items',
        'body' => implode(', ', $bundle_items),
    );

    if ($must_include !== '') {
        $sections[] = array(
            'title' => 'Must include',
            'body' => $must_include,
        );
    }

    return array(
        'title' => sprintf('%s for %s', $bundle_type, $theme),
        'bundle_type' => $bundle_type,
        'sections' => $sections,
        'items' => $bundle_items,
        'item_count' => $item_count,
    );
}

function dcc_tools_base_url() {
    return remove_query_arg('dcc_tool', get_permalink());
}

function dcc_tool_url($tool_key) {
    return add_query_arg('dcc_tool', $tool_key, dcc_tools_base_url());
}

function dcc_render_tools_hub() {
    $tools = dcc_tools_registry();

    ob_start();
    ?>
    <div class="dcc-hub">
        <div class="dcc-hub__header">
            <p class="dcc-kicker">Club tools</p>
            <h2>Available tools</h2>
            <p class="dcc-muted">Choose a tool. More modules can be added later without changing the page structure.</p>
        </div>
        <div class="dcc-hub__grid">
            <?php foreach ($tools as $tool_key => $tool) : ?>
                <article class="dcc-hub-card <?php echo $tool['available'] ? 'is-available' : 'is-soon'; ?>">
                    <div class="dcc-hub-card__top">
                        <span class="dcc-badge"><?php echo esc_html($tool['status']); ?></span>
                    </div>
                    <h3><?php echo esc_html($tool['title']); ?></h3>
                    <p><?php echo esc_html($tool['description']); ?></p>
                    <?php if ($tool['available']) : ?>
                        <a class="dcc-tool-link" href="<?php echo esc_url(dcc_tool_url($tool_key)); ?>">Open tool</a>
                    <?php else : ?>
                        <span class="dcc-tool-link is-disabled">Coming soon</span>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

function dcc_shortcode_tools_hub() {
    return dcc_render_tools_hub();
}
add_shortcode('dcc_tools_hub', 'dcc_shortcode_tools_hub');

function dcc_render_tool_router() {
    $tool_key = sanitize_key(get_query_var('dcc_tool'));
    $tools = dcc_tools_registry();

    if ($tool_key && isset($tools[$tool_key])) {
        if ($tool_key === 'clipart-generator') {
            return dcc_shortcode_clipart_generator();
        }
        if ($tool_key === 'bundle-planner') {
            return dcc_shortcode_bundle_planner();
        }
    }

    return dcc_render_tools_hub();
}

function dcc_shortcode_tool_router() {
    return dcc_render_tool_router();
}
add_shortcode('dcc_tool_router', 'dcc_shortcode_tool_router');

function dcc_filter_tools_page_content($content) {
    if (is_admin()) {
        return $content;
    }

    if (!is_page('tools') && !is_page(2062) && strpos((string) $content, '[dcc_tool_router]') === false) {
        return $content;
    }

    if (!is_page('tools') && !is_page(2062)) {
        return $content;
    }

    return dcc_render_tool_router();
}
add_filter('the_content', 'dcc_filter_tools_page_content', 99);

function dcc_total_items($groups) {
    $total = 0;

    foreach ($groups as $group) {
        $total += max(1, (int) ($group['count'] ?? 1));
    }

    return $total;
}

function dcc_openrouter_extract_json($text) {
    $trimmed = trim((string) $text);
    if ($trimmed === '') {
        return null;
    }

    if ($trimmed[0] === '{' && substr($trimmed, -1) === '}') {
        $data = json_decode($trimmed, true);
        if (is_array($data)) {
            return $data;
        }
    }

    if (preg_match('/\{.*\}/s', $trimmed, $matches)) {
        $data = json_decode($matches[0], true);
        if (is_array($data)) {
            return $data;
        }
    }

    return null;
}

function dcc_normalize_llm_results($data, $groups) {
    if (!is_array($data) || !isset($data['groups']) || !is_array($data['groups'])) {
        return array();
    }

    $target_by_name = array();
    foreach ($groups as $group) {
        $target_by_name[strtolower(trim($group['name']))] = max(1, (int) $group['count']);
    }

    $results = array();
    foreach ($data['groups'] as $group) {
        $group_name = sanitize_text_field($group['name'] ?? '');
        if ($group_name === '') {
            continue;
        }
        $lookup = strtolower(trim($group_name));
        $count = $target_by_name[$lookup] ?? null;
        if ($count === null && !empty($target_by_name)) {
            $first_key = array_key_first($target_by_name);
            $count = $target_by_name[$first_key];
        }
        $items = array();
        foreach ((array) ($group['items'] ?? array()) as $item) {
            $title = sanitize_text_field($item['title'] ?? '');
            $prompt = sanitize_textarea_field($item['prompt'] ?? '');
            if ($prompt === '') {
                continue;
            }
            if ($title === '') {
                $title = 'Prompt';
            }
            $items[] = array('title' => $title, 'prompt' => $prompt);
            if ($count !== null && count($items) >= $count) {
                break;
            }
        }
        if (!empty($items)) {
            $results[] = array('name' => $group_name, 'items' => $items);
        }
    }

    return $results;
}

function dcc_generate_groups_via_openrouter($input, $settings) {
    $api_key = trim((string) ($settings['openrouter_api_key'] ?? ''));
    if ($api_key === '') {
        return new WP_Error('dcc_openrouter_missing_key', 'OpenRouter API key is not configured in plugin settings.');
    }

    $model_id = trim((string) ($settings['model_clipart_generator'] ?? 'openai/gpt-4o-mini'));
    $palette_text = dcc_palette_summary($input['palette'] ?? 'auto', $input['custom_colors'] ?? '');
    $palette_instruction = dcc_palette_instruction_text($input['palette'] ?? 'auto', $input['custom_colors'] ?? '');
    $group_lines = array();
    foreach ((array) ($input['groups'] ?? array()) as $group) {
        $group_lines[] = sprintf('- %s: %d', $group['name'], (int) $group['count']);
    }

    $reference_images = (array) ($input['reference_images'] ?? array());
    $reference_brief = dcc_build_reference_brief_via_openrouter($reference_images, $api_key, $model_id);
    if ($reference_brief === '' && !empty($reference_images)) {
        $reference_colors = array();
        foreach ($reference_images as $image) {
            foreach ((array) ($image['palette'] ?? array()) as $hex) {
                $reference_colors[] = sanitize_text_field((string) $hex);
            }
        }
        $reference_colors = array_values(array_unique(array_filter($reference_colors)));
        if (!empty($reference_colors)) {
            $reference_brief = 'Reference palette extracted from images: ' . implode(', ', array_slice($reference_colors, 0, 10));
        }
    }

    $palette_phrase = dcc_palette_phrase_for_prompt($input['palette'] ?? 'auto', $input['custom_colors'] ?? '');
    $system_prompt = 'You generate premium clipart prompts for cohesive commercial bundles. Return JSON only with shape {"groups":[{"name":"...","items":[{"title":"...","prompt":"..."}]}]}. Titles MUST be in Russian. Prompts MUST be in English. No markdown. No explanations. Keep all prompts in one style family. Prompts should resemble production prompt lines, not abstract descriptions.';
    $user_prompt = implode("\n", array(
        'Theme: ' . ($input['theme'] ?? ''),
        'Template: ' . ($input['template'] ?? ''),
        'Rules: ' . ($input['rules'] ?? ''),
        'Palette summary: ' . $palette_text,
        'Palette policy: ' . $palette_instruction,
        'Palette phrase to include: ' . $palette_phrase,
        $reference_brief !== '' ? 'Reference brief: ' . $reference_brief : 'Reference brief: no image references provided.',
        'Consistency requirements: all prompts must share one style DNA (line quality, shading behavior, softness level, composition simplicity, and background treatment).',
        'Prompt quality requirements: each prompt must include subject details, stylistic details, and palette wording; avoid generic short prompts.',
        'Write each prompt in this style structure:',
        '1) Start with "cute watercolor hand-drawn clipart, isolated on white background, soft pastel colors, clean pencil line,"',
        '2) Then describe the subject and 1-2 distinctive traits inspired by references/theme',
        '3) End with: "In the colour palette ' . $palette_phrase . '."',
        'Keep wording compact but rich enough for high-quality image generation.',
        'Groups and counts:',
        implode("\n", $group_lines),
        'Language: Titles in Russian. Prompts in English only.',
    ));

    $body = array(
        'model' => $model_id,
        'temperature' => (float) ($settings['temperature_clipart_generator'] ?? 0.7),
        'max_tokens' => (int) ($settings['max_tokens_clipart_generator'] ?? 1200),
        'messages' => array(
            array('role' => 'system', 'content' => $system_prompt),
            array('role' => 'user', 'content' => $user_prompt),
        ),
    );

    $response = wp_remote_post(
        'https://openrouter.ai/api/v1/chat/completions',
        array(
            'timeout' => 60,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
                'HTTP-Referer' => home_url('/'),
                'X-Title' => 'Digital Creator Club',
            ),
            'body' => wp_json_encode($body),
        )
    );

    if (is_wp_error($response)) {
        return $response;
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $raw = (string) wp_remote_retrieve_body($response);
    if ($code < 200 || $code >= 300) {
        return new WP_Error('dcc_openrouter_http', 'OpenRouter request failed with HTTP ' . $code . '.');
    }

    $json = json_decode($raw, true);
    $content = (string) ($json['choices'][0]['message']['content'] ?? '');
    $parsed = dcc_openrouter_extract_json($content);
    $normalized = dcc_normalize_llm_results($parsed, (array) ($input['groups'] ?? array()));

    if (empty($normalized)) {
        return new WP_Error('dcc_openrouter_parse', 'Model response format is invalid. Please try again.');
    }

    return $normalized;
}

function dcc_split_groups_into_batches($groups, $batch_size) {
    $batch_size = max(1, (int) $batch_size);
    $batches = array();
    $current = array();
    $current_total = 0;

    foreach ((array) $groups as $group) {
        $name = sanitize_text_field($group['name'] ?? '');
        $remaining = max(1, (int) ($group['count'] ?? 1));

        if ($name === '') {
            continue;
        }

        while ($remaining > 0) {
            if ($current_total >= $batch_size) {
                $batches[] = $current;
                $current = array();
                $current_total = 0;
            }

            $take = min($remaining, $batch_size - $current_total);
            $found = false;

            foreach ($current as $index => $current_group) {
                if ($current_group['name'] === $name) {
                    $current[$index]['count'] += $take;
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $current[] = array(
                    'name' => $name,
                    'count' => $take,
                );
            }

            $current_total += $take;
            $remaining -= $take;

            if ($current_total >= $batch_size) {
                $batches[] = $current;
                $current = array();
                $current_total = 0;
            }
        }
    }

    if (!empty($current)) {
        $batches[] = $current;
    }

    return $batches;
}

function dcc_generate_groups_via_openrouter_batched($input, $settings, $batch_size = 3, $on_batch_success = null) {
    $groups = dcc_normalize_groups((array) ($input['groups'] ?? array()));
    if (empty($groups)) {
        return new WP_Error('dcc_openrouter_empty_groups', 'Add at least one group.');
    }

    $batches = dcc_split_groups_into_batches($groups, $batch_size);
    $combined = array();
    $combined_index = array();

    foreach ($batches as $batch_groups) {
        $batch_input = $input;
        $batch_input['groups'] = $batch_groups;

        $batch_results = dcc_generate_groups_via_openrouter($batch_input, $settings);
        if (is_wp_error($batch_results)) {
            return $batch_results;
        }

        if (is_callable($on_batch_success)) {
            call_user_func($on_batch_success, dcc_total_items($batch_groups));
        }

        foreach ($batch_results as $batch_group) {
            $group_name = (string) ($batch_group['name'] ?? '');
            if ($group_name === '') {
                continue;
            }

            if (!isset($combined_index[$group_name])) {
                $combined_index[$group_name] = count($combined);
                $combined[] = array(
                    'name' => $group_name,
                    'items' => array(),
                );
            }

            $slot_index = $combined_index[$group_name];
            $combined[$slot_index]['items'] = array_merge(
                $combined[$slot_index]['items'],
                (array) ($batch_group['items'] ?? array())
            );
        }
    }

    return $combined;
}

function dcc_consume_user_credits($user_id, $tool_id, $amount) {
    $amount = max(0, (int) $amount);
    $remaining_key = 'dcc_credits_remaining';
    $remaining = (int) get_user_meta($user_id, $remaining_key, true);
    $new_remaining = max(0, $remaining - $amount);

    update_user_meta($user_id, $remaining_key, $new_remaining);

    return $new_remaining;
}
function dcc_shortcode_clipart_generator() {
    $settings = dcc_get_settings();

    if ((int) $settings['require_login'] === 1 && !is_user_logged_in()) {
        return '<div class="dcc-locked">Инструмент доступен только авторизованным участникам клуба.</div>';
    }

    if (!is_user_logged_in()) {
        return '<div class="dcc-locked">Войдите в аккаунт, чтобы использовать инструмент.</div>';
    }

    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id, 'clipart-generator');
    $tools_url = dcc_tools_base_url();

    wp_enqueue_style('dcc-frontend');
    wp_enqueue_script('dcc-frontend');
    wp_localize_script(
        'dcc-frontend',
        'DCC_TOOL',
        array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'creditsPerItem' => dcc_get_tool_request_cost('clipart-generator', $settings),
            'maxGroups' => (int) $settings['max_groups'],
            'maxItemsPerGroup' => DCC_MAX_ITEMS_PER_GROUP,
            'remainingCredits' => (int) $quota['remaining'],
            'monthlyCredits' => (int) $quota['limit'],
        )
    );

    ob_start();
    ?>
    <div class="dcc-muse-page">
        <section class="dcc-muse-hero">
            <div class="dcc-muse-hero__text">
                <h2>Генератор промтов для клипарта</h2>
                <p class="dcc-backlink"><a href="<?php echo esc_url($tools_url); ?>">&larr; К списку инструментов</a></p>
            </div>
            <div class="dcc-muse-hero__visual" aria-hidden="true">💡</div>
        </section>

        <div class="dcc-tool" data-dcc-tool>
            <div class="dcc-tool__hero">
                <div class="dcc-quota">
                    <strong data-dcc-remaining><?php echo esc_html((string) $quota['remaining']); ?></strong>
                    <span>из <?php echo esc_html((string) $quota['limit']); ?> кредитов осталось в текущем цикле</span>
                </div>
            </div>

            <form class="dcc-form" data-dcc-form>
            <div class="dcc-step-head">
                <span class="dcc-step-badge">1</span>
                <h3>Параметры набора</h3>
            </div>
            <label class="dcc-field">
                <span>Тема</span>
                <input type="text" name="theme" value="cozy autumn woodland nursery clipart" />
            </label>

            <label class="dcc-field">
                <span>Шаблон промта</span>
                <textarea name="template" rows="4">cute watercolor hand-drawn clipart, isolated on white background, soft pastel colors, clean pencil line</textarea>
            </label>

            <div class="dcc-groups" data-dcc-groups>
                <div class="dcc-group-head">
                    <span>Группы</span>
                    <span>Количество</span>
                </div>

                <?php foreach (dcc_default_group_rows() as $default_group) : ?>
                    <div class="dcc-group-row" data-dcc-group>
                        <input type="text" name="group_name[]" value="<?php echo esc_attr($default_group['name']); ?>" placeholder="например: животные" />
                        <input type="number" min="1" max="<?php echo esc_attr((string) DCC_MAX_ITEMS_PER_GROUP); ?>" name="group_count[]" value="<?php echo esc_attr((string) $default_group['count']); ?>" />
                        <button type="button" class="dcc-icon-button" data-dcc-remove-group aria-label="Удалить группу">x</button>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="dcc-secondary" data-dcc-add-group>Добавить группу</button>

            <label class="dcc-field">
                <span>Специальные правила</span>
                <textarea name="rules" rows="3">full body, no text, no background, consistent palette, simple shapes</textarea>
            </label>

            <div class="dcc-field">
                <div class="dcc-step-head">
                    <span class="dcc-step-badge">2</span>
                    <h3>Референсы для набора (необязательно)</h3>
                </div>
                <span>Изображения-вдохновение</span>
                <p class="dcc-hint">До 4 изображений для вдохновения по идеям, мотивам и палитре. Мы не копируем чужие работы.</p>
                <div class="dcc-image-slots" data-dcc-image-slots>
                    <?php for ($i = 1; $i <= 4; $i++) : ?>
                        <label class="dcc-image-slot" data-dcc-image-slot>
                            <input type="file" name="inspiration_image_<?php echo esc_attr((string) $i); ?>" accept="image/*" />
                            <span class="dcc-image-slot__inner">
                                <span class="dcc-image-slot__plus">+</span>
                                <span class="dcc-image-slot__text">Нажмите или перетащите</span>
                            </span>
                        </label>
                    <?php endfor; ?>
                </div>
            </div>

            <div class="dcc-field">
                <div class="dcc-step-head">
                    <span class="dcc-step-badge">3</span>
                    <h3>Цветовая палитра</h3>
                </div>
                <span>Палитра</span>
                <div class="dcc-palette-grid">
                    <div class="dcc-palette-tabs" role="group" aria-label="Palette modes">
                        <?php foreach (array('preset', 'custom', 'match_images', 'auto') as $palette_mode) : ?>
                            <?php
                            $palette_mode_label = array(
                                'preset' => 'Готовые',
                                'custom' => 'Свои цвета',
                                'match_images' => 'По рефам',
                                'auto' => 'AI сам',
                            );
                            ?>
                            <label class="dcc-palette-tab <?php echo $palette_mode === 'preset' ? 'is-primary' : ''; ?>">
                                <input type="radio" name="palette_mode" value="<?php echo esc_attr($palette_mode); ?>" <?php checked($palette_mode, 'preset'); ?> />
                                <span class="dcc-palette-tab__label"><?php echo esc_html($palette_mode_label[$palette_mode]); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="dcc-palette-variants" data-dcc-palette-variants aria-label="Preset palettes">
                        <?php foreach (array('beige_boho', 'pink_girl', 'blue_soft', 'sage_moss', 'yellow_sun', 'lavender_dream', 'apricot_soft', 'mint_cream', 'halloween', 'christmas', 'vintage_dusty', 'coastal') as $palette_key) : ?>
                            <?php $palette_option = dcc_palette_options()[$palette_key]; ?>
                            <label class="dcc-palette-option">
                                <input type="radio" name="preset_palette" value="<?php echo esc_attr($palette_key); ?>" <?php checked($palette_key, 'beige_boho'); ?> />
                                <span class="dcc-palette-option__card">
                                    <span class="dcc-palette-option__title"><?php echo esc_html($palette_option['label']); ?></span>
                                    <span class="dcc-palette-swatches" aria-hidden="true">
                                        <?php foreach ($palette_option['swatches'] as $index => $swatch) : ?>
                                            <span class="dcc-palette-swatch" style="<?php echo esc_attr('--dcc-swatch: ' . $swatch . '; --dcc-swatch-delay: ' . ($index * 28) . 'ms;'); ?>"></span>
                                        <?php endforeach; ?>
                                    </span>
                                    <span class="dcc-palette-option__desc"><?php echo esc_html($palette_option['description']); ?></span>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <p class="dcc-hint" data-dcc-palette-note hidden></p>
                </div>
            </div>

            <label class="dcc-field" data-dcc-custom-palette hidden>
                <span>Свои цвета</span>
                <textarea name="custom_colors" rows="2" placeholder="например: #E7D7C9, пудрово-розовый, шалфейный"></textarea>
            </label>

            <div class="dcc-actions">
                <button type="submit" class="dcc-primary">Сгенерировать</button>
                <button type="button" class="dcc-secondary" data-dcc-export-csv disabled>Экспорт CSV</button>
                <span class="dcc-cost">Стоимость: <strong data-dcc-cost>0</strong> кредитов</span>
            </div>
            <div class="dcc-progress" data-dcc-progress hidden>
                <div class="dcc-progress__head">
                    <span class="dcc-progress__label">Генерация промтов...</span>
                    <span class="dcc-progress__count" data-dcc-progress-count>0 из 0</span>
                </div>
                <div class="dcc-progress__bar">
                    <span class="dcc-progress__fill" data-dcc-progress-fill></span>
                </div>
            </div>
        </form>

            <div class="dcc-notice" data-dcc-notice hidden></div>
            <div class="dcc-results" data-dcc-results></div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dcc_clipart_generator', 'dcc_shortcode_clipart_generator');

function dcc_shortcode_bundle_planner() {
    $settings = dcc_get_settings();

    if ((int) $settings['require_login'] === 1 && !is_user_logged_in()) {
        return '<div class="dcc-locked">This tool is available to logged-in club members only.</div>';
    }

    if (!is_user_logged_in()) {
        return '<div class="dcc-locked">Please log in to use this tool.</div>';
    }

    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id, 'bundle-planner');
    $tools_url = dcc_tools_base_url();
    $form_values = array(
        'theme' => 'cozy autumn woodland nursery',
        'audience' => 'Etsy buyers',
        'bundle_type' => 'clipart bundle',
        'item_count' => 6,
        'style' => 'cute watercolor, soft pastel, isolated on white',
        'must_include' => 'consistent palette, no text, no background',
    );

    ob_start();
    ?>
    <div class="dcc-bundle">
        <div class="dcc-tool__hero">
            <div>
                <p class="dcc-kicker">Club tool</p>
                <h2>Bundle Planner</h2>
                <p class="dcc-muted">Plan the structure of a product bundle before you generate prompts or assets. Great for pack outlines and product planning.</p>
                <p class="dcc-backlink"><a href="<?php echo esc_url($tools_url); ?>">&larr; Back to tools</a></p>
            </div>
            <div class="dcc-quota">
                <strong><?php echo esc_html((string) $quota['remaining']); ?></strong>
                <span>of <?php echo esc_html((string) $quota['limit']); ?> credits left in current cycle</span>
            </div>
        </div>
        <div class="dcc-results">
            <section class="dcc-result-group">
                <div class="dcc-result-group__head">
                    <h3>Example bundle plan</h3>
                    <span class="dcc-badge">Preview</span>
                </div>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Theme</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['theme']); ?></p>
                </article>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Audience</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['audience']); ?></p>
                </article>
                <article class="dcc-result-item">
                    <div class="dcc-result-item__head">
                        <strong>Style</strong>
                    </div>
                    <p class="dcc-result-box"><?php echo esc_html($form_values['style']); ?></p>
                </article>
            </section>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dcc_bundle_planner', 'dcc_shortcode_bundle_planner');

function dcc_ajax_generate_clipart() {
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Войдите в аккаунт, чтобы выполнить генерацию.'), 401);
    }

    $settings = dcc_get_settings();
    $user_id = get_current_user_id();
    $quota = dcc_ensure_user_quota($user_id, 'clipart-generator');

    $palette_mode = sanitize_text_field($_POST['palette_mode'] ?? 'preset');
    $preset_palette = sanitize_text_field($_POST['preset_palette'] ?? 'pink_girl');
    $palette_value = 'auto';

    if ($palette_mode === 'preset') {
        $palette_value = $preset_palette;
    } elseif (in_array($palette_mode, array('custom', 'match_images', 'auto'), true)) {
        $palette_value = $palette_mode;
    }

    $payload = array(
        'mode' => sanitize_text_field($_POST['mode'] ?? 'prompts'),
        'theme' => sanitize_text_field($_POST['theme'] ?? ''),
        'template' => sanitize_textarea_field($_POST['template'] ?? ''),
        'rules' => sanitize_textarea_field($_POST['rules'] ?? ''),
        'palette' => $palette_value,
        'custom_colors' => sanitize_textarea_field($_POST['custom_colors'] ?? ''),
        'groups' => array(),
        'reference_images' => dcc_collect_reference_images_from_request(),
    );

    $group_names = isset($_POST['group_name']) ? (array) $_POST['group_name'] : array();
    $group_counts = isset($_POST['group_count']) ? (array) $_POST['group_count'] : array();

    foreach ($group_names as $index => $name) {
        $payload['groups'][] = array(
            'name' => sanitize_text_field($name),
            'count' => isset($group_counts[$index]) ? (int) $group_counts[$index] : 1,
        );
    }

    $payload['groups'] = dcc_normalize_groups($payload['groups']);

    if (empty($payload['groups'])) {
        wp_send_json_error(array('message' => 'Добавьте хотя бы одну группу.'), 400);
    }

    if (count($payload['groups']) > (int) $settings['max_groups']) {
        wp_send_json_error(array('message' => 'Слишком много групп для одного набора.'), 400);
    }

    foreach ($payload['groups'] as $group) {
        if ($group['count'] > DCC_MAX_ITEMS_PER_GROUP) {
            wp_send_json_error(array('message' => 'В одной из групп превышен лимит количества элементов.'), 400);
        }
    }

    $items_requested = dcc_total_items($payload['groups']);
    $cost = $items_requested * dcc_get_tool_request_cost('clipart-generator', $settings);

    if ($cost > $quota['remaining']) {
        wp_send_json_error(array(
            'message' => 'Недостаточно кредитов для этой генерации.',
            'remaining' => $quota['remaining'],
            'cost' => $cost,
        ), 402);
    }

    $results = dcc_generate_groups_via_openrouter_batched(
        $payload,
        $settings,
        3,
        function ($batch_cost) use ($user_id) {
            dcc_consume_user_credits($user_id, 'clipart-generator', $batch_cost);
        }
    );
    if (is_wp_error($results)) {
        error_log('DCC OpenRouter error: ' . $results->get_error_code() . ' | ' . $results->get_error_message());
        wp_send_json_error(array('message' => $results->get_error_message()), 502);
    }
    $remaining = (int) get_user_meta($user_id, 'dcc_credits_remaining', true);

    wp_send_json_success(array(
        'results' => $results,
        'cost' => $cost,
        'remaining' => $remaining,
        'limit' => $quota['limit'],
        'generated_at' => current_time('mysql'),
    ));
}
add_action('wp_ajax_dcc_generate_clipart', 'dcc_ajax_generate_clipart');

