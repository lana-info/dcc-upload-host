<?php
/*
Plugin Name: Digital Creator Club
Description: Digital creator tools for club members.
Version: 0.4.20
*/
require_once __DIR__ . '/digital-creator-club.php';
